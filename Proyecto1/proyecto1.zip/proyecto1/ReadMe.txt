Crear el paquete ingresando los siguientes pasos
En Home crear una carpeta llamada ros, dentro de la cual se debe crear otra llamada src.
En la terminal escribir:
catkin_create_pkg proyecto1
En la carpeta src reemplazar los archivos CMakeLists.txt y package.xml por los proporcionados, además incluir el archivo proyecto1.cpp.
Correr la terminal desde la carpeta ros y escribir: catkin_make

Para correr el programa:
roscore
En otra terminal:
rosrun turtlesim turtlesim_node
En otra terminal: 
. ~/ros/devel/setup.bash
rosrun proyecto1 proyecto1

Ingresar los valores solicitados de coordenadas primero en X, luego en y, luego un ángulo theta (donde 0=0°, 1~45°, 2~100°,...,6~0°, no se por qué ocurre esto, no logré arreglarlo). Después ingresar un tiempo deseado y finalmente decidir si se quiere que todo el movimiento se ejecute en el tiempo deseado o solo la parte lineal (la segunda opción es más precisa). Para elegir la primera opción presionar 'Y' o 'y' y para la segunda opción presionar 'N' o 'n'.
