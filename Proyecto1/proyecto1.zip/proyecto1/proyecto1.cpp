#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "turtlesim/Pose.h"
#include <sstream>
#include <cmath> 
#include <iostream> 

using namespace std;

ros::Publisher velocity_publisher;
ros::Subscriber pose_subscriber;
turtlesim::Pose turtlesim_pose;
		
void poseCallback(const turtlesim::Pose::ConstPtr & pose_message);	
void moveGoal(turtlesim::Pose goal_pose, double distance_tolerance, double goal_Time, bool flag);	
double getDistance(double x1, double y1, double x2, double y2);
double goal_Time;
bool flag;
char x;

int main(int argc, char **argv)
{
	ros::init(argc, argv, "proyecto1");
	ros::NodeHandle n;

	velocity_publisher = n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 1000); 
											  //	/geometry_msgs::Twist is the message type
	pose_subscriber = n.subscribe("/turtle1/pose", 10, poseCallback);	//call poseCallback everytime the turtle pose msg is published over the /turtle1/pose topic.
	ros::Rate loop_rate(0.5); 

	turtlesim::Pose goal_pose;
	goal_pose.x;
	goal_pose.y;
	goal_pose.theta;
	goal_Time;

	//User interface
	cout << "Please enter a value for x:      ";
	cin >> goal_pose.x;
	cout << "Please enter a value for y:      ";
	cin >> goal_pose.y;
	cout << "Please enter a value for theta:  ";
	cin >> goal_pose.theta;
	cout << "Please enter the execution time:  ";
	cin >> goal_Time;
	cout << "Do you want the turtle to perform the entirety of the movements in the stated time(Y) or only the linear part(N)? ";
	cin >> x;
	if (x == 'Y' || x == 'y')
		flag = true;
	else if (x == 'N' || x == 'n')
		flag = false;
	else 
		cout << "Invalid answer, you must type either 'Y' or 'N'. Close the program and try again";

	moveGoal(goal_pose, 0.01, goal_Time, flag);
	loop_rate.sleep();	
	
	ros::spin();

	return 0;
}


//callback function to update the pose of the robot  
void poseCallback(const turtlesim::Pose::ConstPtr & pose_message){
	turtlesim_pose.x=pose_message->x;
	turtlesim_pose.y=pose_message->y;
	turtlesim_pose.theta=pose_message->theta;
}


void moveGoal(turtlesim::Pose goal_pose, double distance_tolerance, double goal_Time, bool flag){
	geometry_msgs::Twist vel_msg;
	ros::Rate loop_rate(10);

	if (!flag) {
		//Rotates to face the goal coordinate
		double angle = abs(atan2(goal_pose.y - turtlesim_pose.y, goal_pose.x - turtlesim_pose.x)-turtlesim_pose.theta);
		double steering_angle;
		while(angle > 0.0001) {
			//angular velocity (steering angle)
			angle = atan2(goal_pose.y - turtlesim_pose.y, goal_pose.x - turtlesim_pose.x)-turtlesim_pose.theta;
			if (angle < 0)
				steering_angle = (-1)*abs(angle);
			else
				steering_angle = abs(angle);	
			angle = abs(angle);
			vel_msg.angular.z = steering_angle;
			velocity_publisher.publish(vel_msg);

			ros::spinOnce();
			loop_rate.sleep();

		}
	
		//Moves in a straight line towards the goal coordinate
		double distance = getDistance(turtlesim_pose.x, turtlesim_pose.y, goal_pose.x, goal_pose.y);
		vel_msg.linear.x = (distance)/goal_Time;
		double t0 = ros::Time::now().toSec();
		double t1 = t0;
		while (t1 - t0 <= goal_Time) {
			velocity_publisher.publish(vel_msg);
			ros::spinOnce();
			loop_rate.sleep();
			t1 = ros::Time::now().toSec();
		}
		//do{
			////linear velocity
			//vel_msg.linear.x = getDistance(turtlesim_pose.x, turtlesim_pose.y, goal_pose.x, goal_pose.y);

			//velocity_publisher.publish(vel_msg);

			//ros::spinOnce();
			//loop_rate.sleep();

		//}while(getDistance(turtlesim_pose.x, turtlesim_pose.y, goal_pose.x, goal_pose.y) > distance_tolerance);
		vel_msg.linear.x = 0;
	
		//Rotates to the goal angle
		angle = abs(turtlesim_pose.theta - goal_pose.theta);
		while(angle > 0.0001) {
			angle = turtlesim_pose.theta - goal_pose.theta;
			if (angle < 0)
				steering_angle = abs(angle);
			else
				steering_angle = (-1)*abs(angle);
			angle = abs(angle);
			vel_msg.angular.z = steering_angle;
			velocity_publisher.publish(vel_msg);
			ros::spinOnce();
			loop_rate.sleep();
		}
		vel_msg.angular.z = 0;
	
		cout<<"Goal reached"<<endl;
		vel_msg.angular.z = 0;
		velocity_publisher.publish(vel_msg);
	}
	if (flag) {
		//Rotates to face the goal coordinate
		double steering_angle;
		double angle;
		double t0 = ros::Time::now().toSec();
		double t1 = t0;
		while(t1 - t0 <= 3*goal_Time/8) {
			angle = (atan2(goal_pose.y-turtlesim_pose.y, goal_pose.x-turtlesim_pose.x) - turtlesim_pose.theta);
			if (angle < 0)
				steering_angle = (-9)*abs(angle);
			else
				steering_angle = 9*abs(angle);
			vel_msg.angular.z = (steering_angle)/goal_Time;
			velocity_publisher.publish(vel_msg);
			ros::spinOnce();
			loop_rate.sleep();
			t1 = ros::Time::now().toSec();
		}
		vel_msg.angular.z = 0;
		//do{
			////angular velocity (steering angle)	
			//vel_msg.angular.z = (atan2(goal_pose.y - turtlesim_pose.y, goal_pose.x - turtlesim_pose.x)-turtlesim_pose.theta);

			//velocity_publisher.publish(vel_msg);

			//ros::spinOnce();
			//loop_rate.sleep();

		//}while((atan2(goal_pose.y - turtlesim_pose.y, goal_pose.x - turtlesim_pose.x)-turtlesim_pose.theta) != 0);
	
		//Moves in a straight line towards the goal coordinate
		double distance = getDistance(turtlesim_pose.x, turtlesim_pose.y, goal_pose.x, goal_pose.y);
		vel_msg.linear.x = (4*distance)/goal_Time;
		t0 = ros::Time::now().toSec();
		t1 = t0;
		while (t1 - t0 <= goal_Time/4) {
			velocity_publisher.publish(vel_msg);
			ros::spinOnce();
			loop_rate.sleep();
			t1 = ros::Time::now().toSec();
		}
		//do{
			////linear velocity
			//vel_msg.linear.x = getDistance(turtlesim_pose.x, turtlesim_pose.y, goal_pose.x, goal_pose.y);

			//velocity_publisher.publish(vel_msg);

			//ros::spinOnce();
			//loop_rate.sleep();

		//}while(getDistance(turtlesim_pose.x, turtlesim_pose.y, goal_pose.x, goal_pose.y) > distance_tolerance);
		vel_msg.linear.x = 0;
	
		//Rotates to the goal angle
		t0 = ros::Time::now().toSec();
		t1 = t0;
		while(t1 - t0 <= (3*goal_Time)/8) {
			angle = turtlesim_pose.theta - goal_pose.theta;
			if (angle < 0)
				steering_angle = abs(angle);
			else
				steering_angle = (-1)*abs(angle);
			vel_msg.angular.z = steering_angle;
			velocity_publisher.publish(vel_msg);
			ros::spinOnce();
			loop_rate.sleep();
			t1 = ros::Time::now().toSec();
		}
		//double current_angle = 0.0;
		//t0 = ros::Time::now().toSec();
		//steering_angle = abs(turtlesim_pose.theta - goal_pose.theta);
		//vel_msg.angular.z = steering_angle;
		//do{
			////angular velocity 	
			//velocity_publisher.publish(vel_msg);
			//double t1 = ros::Time::now().toSec();
			//current_angle = steering_angle * (t1-t0);   //Since d = v*t (it's an aproximation)

			//ros::spinOnce();
			//loop_rate.sleep();

		//}while(current_angle < steering_angle);
		vel_msg.angular.z = 0;
	
		cout<<"Goal reached"<<endl;
		vel_msg.angular.z = 0;
		velocity_publisher.publish(vel_msg);
	}
}

//Gets the euclidean distance between the current and the desired coordinates
double getDistance(double x1, double y1, double x2, double y2){
	return sqrt(pow((x2-x1),2) + pow((y2-y1),2));
}

