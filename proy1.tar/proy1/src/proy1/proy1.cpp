#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "turtlesim/Pose.h"
#include <sstream>

using namespace std;

/* Objs */
ros::Publisher vel_pub;
ros::Subscriber pose_pub;
turtlesim::Pose turtlesim_pose;

/* Const */
const double x_min = 0.0;
const double y_min = 0.0;
const double x_max = 11.0;
const double y_max = 11.0;

const double PI = 3.14159265359;

/* Metodos*/
void rota (double vel_angular, double angle, bool s_horario);
double grad2rad(double angulo_g);
double OrientacionDeseada (double angulo_deseado, double time);
void poseCallback(const turtlesim::Pose::ConstPtr & pose_message);
void avanza(turtlesim::Pose pos_deseada, double tol, double time);
double distancia(double x1, double y1, double x2, double y2);

/* Main */
int main(int argc, char **argv) 
{
  // Initialize the ROS system and become a node.
  ros::init(argc, argv, "proy1");
  ros::NodeHandle n;

/* Variables locales */  

  double vel_angular;
  double angle;
  bool s_horario = 1;
  
  double coord_x;
  double coord_y;
  double time;

  bool otra;

//Publisher object.
  vel_pub = n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 10);

//Subscriber object.
  pose_pub = n.subscribe("/turtle1/pose", 10, poseCallback);

// Loop at 10Hz until the node is shut down.
  ros::Rate loop_rate(10);

  do
  {

//Pide coordenada x
  cout<<"Coordenanda deseada en x: ";
  cin>>coord_x;

//Pide coordenada y
  cout<<"Coordenada deseada en y: ";
  cin>>coord_y;

//Pide el angulo deseado
  cout<<"Angulo de pose final con respecto al eje x: ";
  cin>>angle;

//Pide el tiempo de ejecucion
  cout<<"intervalo de desplazamiento en segundos: ";
  cin>>time;

//actualiza la pose deseada
  turtlesim::Pose pos_deseada;
  pos_deseada.x=coord_x;
  pos_deseada.y=coord_y;
  pos_deseada.theta=0;

//Mueve a la tortuga a la posicion deseada
  avanza(pos_deseada, 0.01, time);
  loop_rate.sleep();
//Gira a la tortuga a la pose deseada
  OrientacionDeseada(angle*PI /180.0 ,time);
  loop_rate.sleep();

//Pregunta si se quiere mover la tortuga otra vez
  cout<<"Quiere mover otra vez la tortuga? (Si=1, No=0) : ";
  cin>>otra;        

  }while(otra);

//Let ROS take over.
  ros::spin();

//Exit
  return 0;


}




void rota (double vel_angular, double relative_angle, bool s_horario)
{


	geometry_msgs::Twist vel_msg;
	   

	   vel_msg.linear.x =0;
	   vel_msg.linear.y =0;
	   vel_msg.linear.z =0;
	   

	   vel_msg.angular.x = 0;
	   vel_msg.angular.y = 0;
	   if (s_horario)
	   		   vel_msg.angular.z =-abs(vel_angular);
	   	   else
	   		   vel_msg.angular.z =abs(vel_angular);


	   double t0 = ros::Time::now().toSec();
	   double current_angle = 0.0;
	   ros::Rate loop_rate(10);
	   do{
		   vel_pub.publish(vel_msg);
		   double t1 = ros::Time::now().toSec();
		   current_angle = vel_angular * (t1-t0);
		   ros::spinOnce();
		   loop_rate.sleep();
	   }while(current_angle<relative_angle);
	   vel_msg.angular.z =0;
	   vel_pub.publish(vel_msg);
}

/*Convierte el angulo de grados a radianes*/
double grad2rad(double angulo_g)
{
	return angulo_g *PI /180.0;
}

/*Calcula la distancia entre puntos*/
double distancia(double x1, double y1, double x2, double y2)
{
    return sqrt(pow((x1-x2),2)+pow((y1-y2),2));
}

/*Rota la tortuga en un angulo absoluto respecto al eje x*/

double OrientacionDeseada (double angulo_deseado, double time)
{

	
	double angulo_rel = angulo_deseado - turtlesim_pose.theta;
  bool s_horario = ((angulo_rel<0)?true:false);
        rota (abs((2*angulo_rel)/time), abs(angulo_rel), s_horario);
}

//actualiza la pose de la tortuga

void poseCallback(const turtlesim::Pose::ConstPtr & pose_message)
{
	turtlesim_pose.x=pose_message->x;
	turtlesim_pose.y=pose_message->y;
	turtlesim_pose.theta=pose_message->theta;
}


void avanza(turtlesim::Pose pos_deseada, double tol, double time)
{

//Inicializa el mensaje
    geometry_msgs::Twist vel_msg;

//Loop de 10 hz.    
    ros::Rate loop_rate(10);

    double in = ros::Time::now().toSec();
    do
    {
        double act = ros::Time::now().toSec();

/**
 *  Se declara la velocidad lineal;  y, z van a ser cero pues la tortuga solo avanzara
 *  hacia adelante en proporcion a la distancia que le flate recorrer
 */

        vel_msg.linear.x = (1.5*distancia(turtlesim_pose.x, turtlesim_pose.y, pos_deseada.x, pos_deseada.y))/((time/2)-(act-in));
        vel_msg.linear.y = 0;
        vel_msg.linear.z = 0;

        vel_msg.angular.x = 0;
        vel_msg.angular.y = 0;
        vel_msg.angular.z = 4*(atan2(pos_deseada.y-turtlesim_pose.y, pos_deseada.x-turtlesim_pose.x)-turtlesim_pose.theta);
        vel_pub.publish(vel_msg);

        ros::spinOnce();
        loop_rate.sleep();

    }while (distancia(turtlesim_pose.x, turtlesim_pose.y, pos_deseada.x, pos_deseada.y)>tol);
//Se para la tortuga al llegar la pose deseada
    cout<<"Yatta!!"<<endl;
    vel_msg.linear.x=0;
    vel_msg.angular.z=0;
    vel_pub.publish(vel_msg);

}

