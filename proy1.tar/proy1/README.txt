README

PAra comenzar a usar este proyecto se debe tener instalado ROS.
Y En tres terminales distintas escribir lo siguiente
1) roscore
2) rosrun turtlesim turtlesim_node
3)	cd ~/proy1/
	source /devel/setup.bash
	rosrun proy1 proy1

en la tercer terminal se va a pedir que se introduzac las cordenadas finales asi como le orientacion engrados y el tiempo en el que se ejecutara

despues la tortuga hara su rayectoria y al final se preguntara si se requiere mover otra vez la tortuga
en caso afirmativo escribir "1" y enter en caso contrario "0".
Al terminar de usar el progrma se aconceja terminarlo con "ctrl+c" en las terminales y posteriormente cerrarlas.
